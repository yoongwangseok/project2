document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('login-modal');
  const loginTrigger = document.querySelector('#header #login-button');
  const loginForm = document.querySelector('#login-form form');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const usernameError = document.getElementById('usernameError');
  const passwordError = document.getElementById('passwordError');
  const tabButtons = document.querySelectorAll('.tab-button');

  if (!loginForm || !usernameInput || !passwordInput) {
    console.error('로그인 폼 또는 입력 필드가 존재하지 않습니다.');
    return;
  }

  let loginType = 'buyer'; // 기본은 구매회원

  const validUsers = {
    buyer: { username: 'buyer1', password: 'pass123' },
    seller: { username: 'seller1', password: 'pass123' },
  };

  // 로그인 버튼 클릭 시 모달 열기
  loginTrigger.addEventListener('click', () => {
    modal.classList.remove('login-hidden'); // 모달을 열 때 'login-hidden' 클래스를 제거
  });

  // 탭 클릭 시 로그인 타입 및 탭 스타일 변경
  tabButtons.forEach((button) => {
    button.addEventListener('click', () => {
      tabButtons.forEach((btn) => btn.classList.remove('active'));
      button.classList.add('active');
      loginType = button.dataset.tab; // "buyer" or "seller"
    });
  });

  // 로그인 폼 제출
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    // 에러 초기화
    usernameError.textContent = '';
    passwordError.textContent = '';

    if (!username) {
      usernameError.textContent = '아이디를 입력해주세요.';
      usernameInput.focus();
      return;
    }

    if (!password) {
      passwordError.textContent = '비밀번호를 입력해주세요.';
      passwordInput.focus();
      return;
    }

    const expected = validUsers[loginType];

    if (username !== expected.username || password !== expected.password) {
      passwordError.textContent = '아이디 또는 비밀번호가 일치하지 않습니다.';
      passwordInput.value = '';
      passwordInput.focus();
      return;
    }

    // 로그인 성공
    alert('로그인 성공!');
    window.location.href = document.referrer || '/';
  });
});
